# Memory Search MCP Server

记忆语义搜索 MCP 服务器：对 Markdown 记忆文件做**向量 + BM25 混合检索**，可对接 OpenClaw、mcporter 或任意 MCP 客户端。

## 功能

- **索引**：扫描 `MEMORY.md`、`RECENT_MEMORY.md`、`memory/**/*.md`，分块后生成 embedding 写入 SQLite
- **搜索**：`memory_search` 混合检索（向量 0.7 + BM25 0.3）
- **读取**：`memory_get` 按路径读取文件
- **同步**：`memory_sync` 手动重建索引
- **状态**：`memory_status` 查看索引与模型信息

## 安装

```bash
cd D:\memory-search-mcp
pip install -r requirements.txt
```

## 环境变量

| 变量 | 必填 | 说明 |
|------|------|------|
| `MEMORY_WORKSPACE` | 是* | 记忆文件根目录（包含 MEMORY.md、memory/ 等） |
| `MEMORY_DB_PATH` | 否 | SQLite 索引路径，默认 `<workspace>/../.memory_search/search_index.sqlite` |
| `DASHSCOPE_API_KEY` | 二选一 | 阿里云 DashScope（推荐） |
| `OPENAI_API_KEY` | 二选一 | OpenAI |
| `EMBEDDING_PROVIDER` | 否 | `dashscope` 或 `openai`，不设则自动按 Key 选择 |
| `EMBEDDING_MODEL` | 否 | 默认 dashscope=text-embedding-v3，openai=text-embedding-3-small |

\* 不设时默认使用本目录下的 `workspace` 文件夹（便于单机打包测试）。

## 对接 OpenClaw / mcporter

在 `mcporter.json` 的 `mcpServers` 里增加：

```json
"memory_search": {
  "command": "python",
  "args": ["D:\\memory-search-mcp\\mcp_memory_server.py"],
  "env": {
    "MEMORY_WORKSPACE": "D:\\.openclaw\\.openclaw\\workspace",
    "MEMORY_DB_PATH": "D:\\.openclaw\\.openclaw\\memory\\search_index.sqlite",
    "DASHSCOPE_API_KEY": "你的 DashScope API Key"
  }
}
```

将 `D:\memory-search-mcp` 和路径按实际安装位置修改；API Key 建议用环境变量或本地配置，不要提交到仓库。

调用示例：

```bash
mcporter call memory_search.memory_search query="用户偏好"
mcporter call memory_search.memory_get path="MEMORY.md"
mcporter call memory_search.memory_sync
mcporter call memory_search.memory_status
```

## 打包给别人用

1. 复制整个 `D:\memory-search-mcp` 目录（或打包成 zip）。
2. 对方安装依赖：`pip install -r requirements.txt`。
3. 对方设置环境变量（或在其 mcporter/OpenClaw 的 `env` 里配置）：
   - `MEMORY_WORKSPACE`：他的记忆根目录
   - `MEMORY_DB_PATH`：（可选）他的索引库路径
   - `DASHSCOPE_API_KEY` 或 `OPENAI_API_KEY` 二选一。
4. 在对方的 mcporter 配置里添加上述 `memory_search` 条目，`args` 指向其本地的 `mcp_memory_server.py` 路径。

## 本地快速试运行（不依赖 OpenClaw）

```bash
# 在本目录下建 workspace，放入 MEMORY.md 或 memory/*.md
mkdir workspace
echo # 测试记忆 > workspace\MEMORY.md

# 设置 API Key 后启动（stdio 模式，由 MCP 客户端连接）
set DASHSCOPE_API_KEY=sk-xxx
python mcp_memory_server.py
```

## 技术说明

- 分块：tiktoken cl100k_base，400 tokens/块，80 overlap
- 存储：SQLite + FTS5 全文索引
- 检索：向量余弦相似度 × 0.7 + BM25 × 0.3，min_score 0.35 过滤

## License

MIT

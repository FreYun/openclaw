#!/usr/bin/env python3
"""
Memory Search MCP Server
记忆语义搜索 MCP 服务器（向量 + BM25 混合搜索），可对接 OpenClaw / mcporter 或任意 MCP 客户端。

依赖: pip install -r requirements.txt
运行: python mcp_memory_server.py   （stdio，由 mcporter 或 MCP 客户端启动）

环境变量（必填）:
  MEMORY_WORKSPACE   - 记忆文件根目录（内含 MEMORY.md、RECENT_MEMORY.md、memory/**/*.md）
  MEMORY_DB_PATH     - SQLite 索引文件路径（如不指定则用 <MEMORY_WORKSPACE>/../.memory_search/search_index.sqlite）

Session 扫描（可选）:
  MEMORY_INCLUDE_SESSIONS - 设为 1 或 true 时，同时索引 agent session 对话（*.jsonl）
  MEMORY_SESSIONS_DIR     - session 目录；不设时默认 <MEMORY_WORKSPACE>/../agents/main/sessions

Embedding（二选一）:
  DASHSCOPE_API_KEY  - 阿里云 DashScope API Key（优先；未设时尝试从 ~/.openclaw/openclaw.json 的 env 中读取）
  OPENAI_API_KEY     - OpenAI API Key（备选）
  EMBEDDING_PROVIDER - 可选 "dashscope" | "openai"
  EMBEDDING_MODEL    - 可选，默认 dashscope=text-embedding-v3, openai=text-embedding-3-small
  EMBEDDING_BATCH_SIZE - 单次请求条数，默认 20（大文件如 MEMORY.md 会分批，避免超时/4xx）
  EMBEDDING_TIMEOUT    - 单次请求超时秒数，默认 120
"""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import sys
import time
from pathlib import Path
from typing import List, Dict, Optional, Tuple

# ---------------------------------------------------------------------------
# 配置（均来自环境变量，无硬编码路径）
# ---------------------------------------------------------------------------
def _get_workspace_dir() -> Path:
    v = os.environ.get("MEMORY_WORKSPACE", "").strip()
    if v:
        return Path(v).resolve()
    # 便携默认：脚本所在目录下的 workspace 文件夹
    base = Path(__file__).resolve().parent
    return base / "workspace"


def _get_db_path() -> Path:
    v = os.environ.get("MEMORY_DB_PATH", "").strip()
    if v:
        return Path(v).resolve()
    # 便携默认：与 workspace 同级的 .memory_search/search_index.sqlite
    ws = _get_workspace_dir()
    return ws.parent / ".memory_search" / "search_index.sqlite"


def _get_sessions_dir(workspace: Path) -> Optional[Path]:
    """若启用 session 扫描，返回 session 目录；否则返回 None。"""
    if os.environ.get("MEMORY_INCLUDE_SESSIONS", "").strip().lower() not in ("1", "true", "yes"):
        return None
    v = os.environ.get("MEMORY_SESSIONS_DIR", "").strip()
    if v:
        p = Path(v).resolve()
        return p if p.is_dir() else None
    # 默认：workspace 上级的 agents/main/sessions
    default = workspace.parent / "agents" / "main" / "sessions"
    return default if default.is_dir() else None


WORKSPACE_DIR = _get_workspace_dir()
DB_PATH = _get_db_path()

CHUNK_MAX_TOKENS = 400
CHUNK_OVERLAP = 80
VECTOR_WEIGHT = 0.7
TEXT_WEIGHT = 0.3
DEFAULT_MAX_RESULTS = 6
DEFAULT_MIN_SCORE = 0.35
# Embedding 单次请求条数（DashScope 上限 10，OpenAI 可更大）
EMBEDDING_BATCH_SIZE = int(os.environ.get("EMBEDDING_BATCH_SIZE", "10"))
# Embedding 请求超时（秒），可适当调大避免 60s 不够
EMBEDDING_TIMEOUT = float(os.environ.get("EMBEDDING_TIMEOUT", "120"))

# ---------------------------------------------------------------------------
# Embedding Provider
# ---------------------------------------------------------------------------

_embedding_client = None
_embedding_model = None
_embedding_dimensions = None


def _get_dashscope_key_from_openclaw() -> str:
    """从 OpenClaw 的 openclaw.json 中读取 DASHSCOPE_API_KEY，找到后注入到 os.environ。"""
    # 明确指定路径时只读该文件
    explicit = os.environ.get("OPENCLAW_JSON_PATH", "").strip()
    if explicit:
        candidates = [Path(explicit)]
    else:
        candidates = []
        try:
            candidates.append(Path.home() / ".openclaw" / "openclaw.json")
        except Exception:
            pass
        if os.environ.get("USERPROFILE"):
            p = Path(os.environ["USERPROFILE"]) / ".openclaw" / "openclaw.json"
            if p not in candidates:
                candidates.append(p)
        if os.name == "nt":
            # 使用盘符根路径，避免 Path("D:") 在部分环境下解析异常
            for drive in ("D:\\", "C:\\"):
                candidates.append(Path(drive) / ".openclaw" / "openclaw.json")
        # 脚本所在盘根目录
        try:
            script_drive = Path(__file__).resolve().drive
            if script_drive:
                candidates.append(Path(f"{script_drive}\\.openclaw\\openclaw.json"))
        except Exception:
            pass
    for path in candidates:
        if not path.is_file():
            continue
        try:
            raw = path.read_text(encoding="utf-8", errors="replace")
            # 先尝试直接解析；若含 // 注释再尝试去掉整行注释（避免截断 URL 中的 https://）
            try:
                cfg = json.loads(raw)
            except json.JSONDecodeError:
                lines = []
                for line in raw.split("\n"):
                    stripped = line.rstrip()
                    # 仅当 // 出现在行首或前导空白后、且不在引号内时视为注释
                    if "//" in stripped:
                        idx = stripped.index("//")
                        if idx == 0 or (idx > 0 and stripped[idx - 1] not in (":", "/")):
                            stripped = stripped[:idx].rstrip()
                    lines.append(stripped)
                cfg = json.loads("\n".join(lines))
        except Exception:
            continue
        env = cfg.get("env") or {}
        vars_ = env.get("vars") or {}
        key = (
            env.get("DASHSCOPE_API_KEY")
            or vars_.get("DASHSCOPE_API_KEY")
            or env.get("QWEN_API_KEY")
            or vars_.get("QWEN_API_KEY")
        )
        if not key and isinstance(cfg.get("models"), dict):
            prov = (cfg.get("models") or {}).get("providers") or {}
            for name in ("bailian", "dashscope", "qwen"):
                if isinstance(prov.get(name), dict):
                    key = prov[name].get("apiKey") or prov[name].get("api_key")
                    if key:
                        break
        if key and isinstance(key, str) and key.strip():
            key = key.strip()
            os.environ["DASHSCOPE_API_KEY"] = key  # 注入到环境，后续逻辑统一用 env
            return key
    return ""


# 模块加载时若未设置 key 则尝试从 openclaw.json 注入，便于 Cursor/其他进程直接起 MCP 时可用
if not (os.environ.get("DASHSCOPE_API_KEY") or os.environ.get("OPENAI_API_KEY")):
    _get_dashscope_key_from_openclaw()


def _init_embedding():
    """延迟初始化 embedding 客户端（首次调用时触发）"""
    global _embedding_client, _embedding_model, _embedding_dimensions

    if _embedding_client is not None:
        return

    from openai import OpenAI

    provider = os.environ.get("EMBEDDING_PROVIDER", "").lower()
    dashscope_key = (os.environ.get("DASHSCOPE_API_KEY") or "").strip() or _get_dashscope_key_from_openclaw()
    openai_key = os.environ.get("OPENAI_API_KEY", "")

    if not provider:
        provider = "dashscope" if dashscope_key else "openai"

    if provider == "dashscope":
        if not dashscope_key:
            raise RuntimeError("DASHSCOPE_API_KEY 未设置。请设置环境变量或在使用处配置。")
        _embedding_client = OpenAI(
            api_key=dashscope_key,
            base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
            timeout=EMBEDDING_TIMEOUT,
        )
        _embedding_model = os.environ.get("EMBEDDING_MODEL", "text-embedding-v3")
        _embedding_dimensions = 1024
    else:
        if not openai_key:
            raise RuntimeError("OPENAI_API_KEY 未设置。请设置环境变量或在使用处配置。")
        _embedding_client = OpenAI(api_key=openai_key, timeout=EMBEDDING_TIMEOUT)
        _embedding_model = os.environ.get("EMBEDDING_MODEL", "text-embedding-3-small")
        _embedding_dimensions = 1536


def embed_texts(texts: List[str]) -> List[List[float]]:
    _init_embedding()
    out: List[List[float]] = []
    for i in range(0, len(texts), EMBEDDING_BATCH_SIZE):
        batch = texts[i : i + EMBEDDING_BATCH_SIZE]
        resp = _embedding_client.embeddings.create(model=_embedding_model, input=batch)
        out.extend([item.embedding for item in resp.data])
    return out


def embed_query(text: str) -> List[float]:
    return embed_texts([text])[0]


# ---------------------------------------------------------------------------
# Markdown 分块（tiktoken cl100k_base）
# ---------------------------------------------------------------------------

_tiktoken_enc = None


def _enc():
    global _tiktoken_enc
    if _tiktoken_enc is None:
        import tiktoken
        _tiktoken_enc = tiktoken.get_encoding("cl100k_base")
    return _tiktoken_enc


def chunk_markdown(content: str, max_tokens: int = CHUNK_MAX_TOKENS, overlap: int = CHUNK_OVERLAP) -> List[dict]:
    enc = _enc()
    lines = content.split("\n")
    chunks: List[dict] = []
    current_chunk: List[str] = []
    current_tokens = 0
    start_line = 0

    for i, line in enumerate(lines):
        lt = len(enc.encode(line))
        if current_tokens + lt > max_tokens and current_chunk:
            chunks.append({
                "text": "\n".join(current_chunk),
                "start_line": start_line,
                "end_line": i - 1,
            })
            overlap_lines: List[str] = []
            overlap_tokens = 0
            for j in range(len(current_chunk) - 1, -1, -1):
                ol = current_chunk[j]
                olt = len(enc.encode(ol))
                if overlap_tokens + olt <= overlap:
                    overlap_lines.insert(0, ol)
                    overlap_tokens += olt
                else:
                    break
            current_chunk = overlap_lines + [lines[i]]
            current_tokens = overlap_tokens + lt
            start_line = i - len(overlap_lines)
        else:
            current_chunk.append(line)
            current_tokens += lt

    if current_chunk:
        chunks.append({
            "text": "\n".join(current_chunk),
            "start_line": start_line,
            "end_line": len(lines) - 1,
        })
    return chunks


# ---------------------------------------------------------------------------
# SQLite Indexer
# ---------------------------------------------------------------------------

def _init_db(db_path: Path):
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
    c.execute("""CREATE TABLE IF NOT EXISTS files (
        path TEXT PRIMARY KEY, source TEXT NOT NULL DEFAULT 'memory',
        hash TEXT NOT NULL, mtime INTEGER NOT NULL, size INTEGER NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS chunks (
        id TEXT PRIMARY KEY, path TEXT NOT NULL, source TEXT NOT NULL DEFAULT 'memory',
        start_line INTEGER NOT NULL, end_line INTEGER NOT NULL,
        hash TEXT NOT NULL, model TEXT NOT NULL, text TEXT NOT NULL,
        embedding TEXT NOT NULL, updated_at INTEGER NOT NULL)""")
    c.execute("CREATE INDEX IF NOT EXISTS idx_chunks_path ON chunks(path)")
    try:
        c.execute("""CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
            text, id UNINDEXED, path UNINDEXED, source UNINDEXED,
            model UNINDEXED, start_line UNINDEXED, end_line UNINDEXED)""")
    except sqlite3.OperationalError:
        pass
    conn.commit()
    conn.close()


def _file_hash(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _scan_memory_files(workspace: Path) -> List[Tuple[str, Path]]:
    """扫描 workspace 下的记忆文件"""
    files: List[Tuple[str, Path]] = []
    memory_dir = workspace / "memory"
    if memory_dir.exists():
        for md in memory_dir.rglob("*.md"):
            files.append(("memory", md))
    for name in ("MEMORY.md", "RECENT_MEMORY.md"):
        p = workspace / name
        if p.exists():
            files.append(("memory", p))
    return files


def _scan_session_files(workspace: Path) -> List[Tuple[str, Path]]:
    """扫描 session 目录下的 *.jsonl 对话文件（需 MEMORY_INCLUDE_SESSIONS=1）"""
    sessions_dir = _get_sessions_dir(workspace)
    if sessions_dir is None:
        return []
    files: List[Tuple[str, Path]] = []
    for j in sessions_dir.glob("*.jsonl"):
        if j.is_file() and not j.name.startswith("."):
            files.append(("session", j))
    return files


def _extract_session_text(file_path: Path) -> str:
    """从 session JSONL 中提取可索引的对话文本（user/assistant 消息内容）"""
    lines_out: List[str] = []
    try:
        raw = file_path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(obj, dict):
            continue
        msg = obj.get("message") if obj.get("type") == "message" else obj
        if not isinstance(msg, dict):
            continue
        role = (msg.get("role") or "").strip().lower()
        if role not in ("user", "assistant"):
            continue
        content = msg.get("content")
        if isinstance(content, str) and content.strip():
            lines_out.append(f"[{role}]\n{content.strip()}")
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    text = (part.get("text") or "").strip()
                    if text:
                        lines_out.append(f"[{role}]\n{text}")
    return "\n\n".join(lines_out) if lines_out else ""


def sync_index(workspace: Path, db_path: Path) -> dict:
    """同步索引，返回统计信息。扫描 memory 文件 + 可选 session 目录下的 *.jsonl。"""
    _init_db(db_path)
    _init_embedding()
    files = _scan_memory_files(workspace) + _scan_session_files(workspace)
    conn = sqlite3.connect(str(db_path))
    cursor = conn.cursor()
    indexed = 0
    skipped = 0
    errors = 0

    for source, fpath in files:
        try:
            if source == "session":
                content = _extract_session_text(fpath)
                rel = f"sessions/{fpath.name}"
            else:
                content = fpath.read_text(encoding="utf-8")
                rel = str(fpath.relative_to(workspace)).replace("\\", "/")
            if not content.strip():
                skipped += 1
                continue
            fhash = _file_hash(content)
            cursor.execute("SELECT hash FROM files WHERE path = ?", (rel,))
            row = cursor.fetchone()
            if row and row[0] == fhash:
                skipped += 1
                continue
            chunks = chunk_markdown(content)
            if not chunks:
                skipped += 1
                continue
            texts = [ch["text"] for ch in chunks]
            embeddings = embed_texts(texts)
            cursor.execute("DELETE FROM chunks WHERE path = ?", (rel,))
            try:
                cursor.execute("DELETE FROM chunks_fts WHERE path = ?", (rel,))
            except sqlite3.OperationalError:
                pass
            now = int(time.time() * 1000)
            for i, (ch, emb) in enumerate(zip(chunks, embeddings)):
                cid = f"{rel}:{i}"
                chash = hashlib.sha256(ch["text"].encode("utf-8")).hexdigest()
                cursor.execute(
                    "INSERT OR REPLACE INTO chunks VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (cid, rel, source, ch["start_line"], ch["end_line"],
                     chash, _embedding_model, ch["text"], json.dumps(emb), now),
                )
                try:
                    cursor.execute(
                        "INSERT INTO chunks_fts (id, path, source, model, start_line, end_line, text) VALUES (?,?,?,?,?,?,?)",
                        (cid, rel, source, _embedding_model, ch["start_line"], ch["end_line"], ch["text"]),
                    )
                except sqlite3.OperationalError:
                    pass
            stat = fpath.stat()
            cursor.execute(
                "INSERT OR REPLACE INTO files VALUES (?,?,?,?,?)",
                (rel, source, fhash, int(stat.st_mtime * 1000), stat.st_size),
            )
            indexed += 1
        except Exception as e:
            errors += 1
            print(f"[memory-mcp] index error {fpath}: {e}", file=sys.stderr)
    conn.commit()
    conn.close()
    return {"indexed": indexed, "skipped": skipped, "errors": errors}


# ---------------------------------------------------------------------------
# 混合搜索 (Vector + BM25)
# ---------------------------------------------------------------------------

def _vector_search(db_path: Path, query_emb: List[float], limit: int) -> List[Dict]:
    import numpy as np
    conn = sqlite3.connect(str(db_path))
    cursor = conn.cursor()
    cursor.execute("SELECT id, path, text, start_line, end_line, embedding FROM chunks")
    qv = np.array(query_emb, dtype=np.float32)
    qnorm = np.linalg.norm(qv)
    results: List[Dict] = []
    for row in cursor.fetchall():
        cid, path, text, sl, el, emb_json = row
        try:
            cv = np.array(json.loads(emb_json), dtype=np.float32)
            cnorm = np.linalg.norm(cv)
            sim = float(np.dot(qv, cv) / (qnorm * cnorm)) if cnorm > 0 else 0.0
            results.append({"id": cid, "path": path, "text": text, "start_line": sl, "end_line": el, "score": sim, "type": "vector"})
        except Exception:
            continue
    conn.close()
    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:limit]


def _bm25_search(db_path: Path, query: str, limit: int) -> List[Dict]:
    conn = sqlite3.connect(str(db_path))
    cursor = conn.cursor()
    escaped = query.replace('"', '""')
    results: List[Dict] = []
    try:
        cursor.execute(
            'SELECT id, path, text, start_line, end_line, rank FROM chunks_fts WHERE chunks_fts MATCH ? ORDER BY rank LIMIT ?',
            (f'"{escaped}"', limit),
        )
        for row in cursor.fetchall():
            cid, path, text, sl, el, rank = row
            score = 1 / (1 + max(0, rank))
            results.append({"id": cid, "path": path, "text": text, "start_line": sl, "end_line": el, "score": score, "type": "text"})
    except sqlite3.OperationalError:
        pass
    conn.close()
    return results


def hybrid_search(
    db_path: Path,
    query: str,
    max_results: int = DEFAULT_MAX_RESULTS,
    min_score: float = DEFAULT_MIN_SCORE,
) -> List[Dict]:
    query_emb = embed_query(query)
    vr = _vector_search(db_path, query_emb, max_results * 2)
    tr = _bm25_search(db_path, query, max_results * 2)
    merged: Dict[str, Dict] = {}
    for r in vr:
        merged[r["id"]] = {**r, "vector_score": r["score"], "text_score": 0.0}
    for r in tr:
        if r["id"] in merged:
            merged[r["id"]]["text_score"] = max(merged[r["id"]].get("text_score", 0), r["score"])
        else:
            merged[r["id"]] = {**r, "vector_score": 0.0, "text_score": r["score"]}
    for v in merged.values():
        v["score"] = VECTOR_WEIGHT * v.get("vector_score", 0) + TEXT_WEIGHT * v.get("text_score", 0)
    ranked = sorted(merged.values(), key=lambda x: x["score"], reverse=True)
    return [r for r in ranked[:max_results] if r["score"] >= min_score]


# ---------------------------------------------------------------------------
# MCP 服务器
# ---------------------------------------------------------------------------

def main() -> None:
    from mcp.server.fastmcp import FastMCP

    _init_db(DB_PATH)
    mcp = FastMCP("memory_search")

    @mcp.tool()
    def memory_search(query: str, max_results: int = 6) -> str:
        """搜索记忆（向量语义 + BM25 关键词混合搜索）。返回相关记忆片段及来源文件、行号、分数。"""
        query = (query or "").strip()
        if not query:
            return "Error: query 不能为空"
        max_results = min(max(max_results, 1), 20)
        try:
            results = hybrid_search(DB_PATH, query, max_results=max_results)
        except Exception as e:
            return f"Error: {e}"
        if not results:
            return "未找到相关记忆。可换关键词重试。"
        lines = []
        for i, r in enumerate(results, 1):
            path = r.get("path", "?")
            score = r.get("score", 0)
            sl, el = r.get("start_line", 0), r.get("end_line", 0)
            text = r.get("text", "")[:300]
            lines.append(f"{i}. [{path}] L{sl}-{el} (score: {score:.3f})\n{text}")
        return f"找到 {len(results)} 条相关记忆：\n\n" + "\n\n".join(lines)

    @mcp.tool()
    def memory_get(path: str, start_line: int = 0, lines: int = 0) -> str:
        """读取记忆文件内容。path 为相对 workspace 的路径（如 memory/episodic/2026-03-01.md）。"""
        path = (path or "").strip()
        if not path:
            return "Error: path 不能为空"
        fpath = WORKSPACE_DIR / path
        if not fpath.exists():
            return f"Error: 文件不存在 {path}"
        try:
            all_lines = fpath.read_text(encoding="utf-8").splitlines(keepends=True)
            if start_line == 0 and lines == 0:
                return "".join(all_lines)
            end = start_line + lines if lines > 0 else len(all_lines)
            return "".join(all_lines[start_line:end])
        except Exception as e:
            return f"Error: {e}"

    @mcp.tool()
    def memory_sync() -> str:
        """同步记忆索引。扫描 workspace 下的 MEMORY.md、RECENT_MEMORY.md 和 memory/**/*.md，对变更文件重新分块并写入索引。"""
        try:
            stats = sync_index(WORKSPACE_DIR, DB_PATH)
            return f"同步完成：新索引 {stats['indexed']} 个文件，跳过 {stats['skipped']} 个未变更，失败 {stats['errors']} 个。"
        except Exception as e:
            return f"Error: {e}"

    @mcp.tool()
    def memory_status() -> str:
        """查看记忆索引状态：已索引文件数、chunk 数、FTS5 状态、embedding 模型等。"""
        try:
            vector_ok = False
            try:
                _init_embedding()
                vector_ok = _embedding_client is not None
            except Exception:
                pass
            conn = sqlite3.connect(str(DB_PATH))
            c = conn.cursor()
            c.execute("SELECT COUNT(*) FROM files")
            fc = c.fetchone()[0]
            c.execute("SELECT COUNT(*) FROM chunks")
            cc = c.fetchone()[0]
            fts = False
            try:
                c.execute("SELECT COUNT(*) FROM chunks_fts")
                fts = True
            except sqlite3.OperationalError:
                pass
            conn.close()
            emb_line = ""
            if vector_ok:
                emb_line = f"  Embedding 模型: {_embedding_model}\n  向量维度: {_embedding_dimensions}\n  批大小: {EMBEDDING_BATCH_SIZE}  超时: {EMBEDDING_TIMEOUT}s\n"
            else:
                emb_line = "  向量搜索: ❌ 未配置（请设置 DASHSCOPE_API_KEY 或 OPENAI_API_KEY）\n"
            return (
                f"记忆索引状态：\n"
                f"  已索引文件: {fc}\n  总 chunk 数: {cc}\n"
                f"  FTS5 全文索引: {'✅ 可用' if fts else '❌ 不可用'}\n  向量搜索: {'✅ 可用' if vector_ok else '❌ 不可用'}\n"
                f"{emb_line}"
                f"  Workspace: {WORKSPACE_DIR}\n  数据库: {DB_PATH}"
            )
        except Exception as e:
            return f"Error: {e}"

    try:
        stats = sync_index(WORKSPACE_DIR, DB_PATH)
        print(f"[memory-mcp] 启动同步: indexed={stats['indexed']} skipped={stats['skipped']} errors={stats['errors']}", file=sys.stderr)
    except Exception as e:
        print(f"[memory-mcp] 启动同步失败（首次搜索时重试）: {e}", file=sys.stderr)

    mcp.run()


if __name__ == "__main__":
    main()
    sys.exit(0)
